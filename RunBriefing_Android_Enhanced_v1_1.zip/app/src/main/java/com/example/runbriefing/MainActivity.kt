package com.example.runbriefing

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

private data class RunRecord(val date: String, val km: Double, val seconds: Long, val paceSecPerKm: Double, val calories: Int)
private data class Headline(val title: String, val source: String, val link: String = "")
private data class QuoteCard(val quote: String, val author: String, val topic: String, val context: String)

private val quoteLibrary = listOf(
    QuoteCard("It always seems impossible until it’s done.", "Nelson Mandela", "Motivation", "A reminder to begin before a task feels easy."),
    QuoteCard("The secret of getting ahead is getting started.", "Mark Twain", "Study", "Turn a large syllabus into one small topic and start it."),
    QuoteCard("Risk comes from not knowing what you’re doing.", "Warren Buffett", "Trading", "Know your setup, risk, invalidation and position size before a trade."),
    QuoteCard("The unexamined life is not worth living.", "Socrates", "Philosophy", "Reflect on decisions so the same mistakes become lessons."),
    QuoteCard("If you want to go fast, go alone. If you want to go far, go together.", "Proverb", "Life", "Consistency and support matter over the long run."),
    QuoteCard("It is not that I’m so smart, it’s just that I stay with problems longer.", "Albert Einstein", "Logic", "Work through a problem methodically instead of guessing."),
    QuoteCard("The future depends on what you do today.", "Mahatma Gandhi", "Optimism", "Today’s small habits shape future options."),
    QuoteCard("A journey of a thousand miles begins with a single step.", "Lao Tzu", "Running", "Start at your current fitness level and build gradually.")
)

class MainActivity : ComponentActivity() {
    private lateinit var fused: FusedLocationProviderClient
    private var callback: LocationCallback? = null
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fused = LocationServices.getFusedLocationProviderClient(this)
        setContent {
            RunBriefingApp(
                startGps = { onLoc ->
                    val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    if (!fine && !coarse) {
                        permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                    } else {
                        val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1500L).setMinUpdateDistanceMeters(2f).build()
                        callback = object : LocationCallback() {
                            override fun onLocationResult(result: LocationResult) { result.lastLocation?.let(onLoc) }
                        }
                        fused.requestLocationUpdates(req, callback!!, mainLooper)
                    }
                },
                stopGps = { callback?.let { fused.removeLocationUpdates(it) }; callback = null },
                context = this
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RunBriefingApp(startGps: ((Location) -> Unit) -> Unit, stopGps: () -> Unit, context: Context) {
    var tab by remember { mutableIntStateOf(0) }
    var showQuote by remember { mutableStateOf(false) }
    var currentQuote by remember { mutableStateOf(quoteLibrary.first()) }
    var quoteIndex by remember { mutableIntStateOf(0) }
    var marketHeadlines by remember { mutableStateOf(listOf<Headline>()) }
    var loadingNews by remember { mutableStateOf(false) }
    var lastUpdated by remember { mutableStateOf("Not refreshed yet") }
    var refreshMessage by remember { mutableStateOf("Connect to the internet and refresh for updates.") }
    var running by remember { mutableStateOf(false) }
    var paused by remember { mutableStateOf(false) }
    var startTime by remember { mutableLongStateOf(0L) }
    var elapsed by remember { mutableLongStateOf(0L) }
    var pausedAccumulated by remember { mutableLongStateOf(0L) }
    var pauseStarted by remember { mutableLongStateOf(0L) }
    var km by remember { mutableDoubleStateOf(0.0) }
    var lastLocation by remember { mutableStateOf<Location?>(null) }
    var paceSec by remember { mutableDoubleStateOf(0.0) }
    var speed by remember { mutableDoubleStateOf(0.0) }
    var route by remember { mutableStateOf(listOf<Pair<Double, Double>>()) }
    var weather by remember { mutableStateOf("Loading Guwahati weather…") }
    var headlines by remember { mutableStateOf(listOf<Headline>()) }
    var newsStatus by remember { mutableStateOf("Fetching headlines…") }
    val runs = remember { mutableStateListOf<RunRecord>() }
    val prefs = remember { context.getSharedPreferences("runbriefing", Context.MODE_PRIVATE) }

    fun persistRuns() {
        val encoded = runs.joinToString("\n") { listOf(it.date, it.km, it.seconds, it.paceSecPerKm, it.calories).joinToString("|") }
        prefs.edit().putString("runs", encoded).apply()
    }
    LaunchedEffect(Unit) {
        prefs.getString("runs", "").orEmpty().lines().filter { it.isNotBlank() }.forEach { line ->
            runCatching {
                val p = line.split("|")
                runs.add(RunRecord(p[0], p[1].toDouble(), p[2].toLong(), p[3].toDouble(), p[4].toDouble().toInt()))
            }
        }
    }
    LaunchedEffect(running, paused) {
        while (running && !paused) {
            elapsed = (System.currentTimeMillis() - startTime - pausedAccumulated) / 1000
            paceSec = if (km > 0.03) elapsed / km else 0.0
            speed = if (elapsed > 0) km / (elapsed / 3600.0) else 0.0
            delay(1000)
        }
    }
    suspend fun refreshWeather() {
        withContext(Dispatchers.IO) {
            try {
                val client = OkHttpClient()
                val url = "https://api.open-meteo.com/v1/forecast?latitude=26.1445&longitude=91.7362&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=Asia%2FKolkata"
                val j = JSONObject(client.newCall(Request.Builder().url(url).build()).execute().use { it.body?.string() ?: "{}" })
                val c = j.optJSONObject("current"); val d = j.optJSONObject("daily")
                weather = if (c != null) "Guwahati • ${c.optDouble("temperature_2m").roundToInt()}°C • feels like ${c.optDouble("apparent_temperature").roundToInt()}°C\nHumidity ${c.optInt("relative_humidity_2m")}% • Wind ${c.optDouble("wind_speed_10m").roundToInt()} km/h\nToday ${d?.optJSONArray("temperature_2m_min")?.optDouble(0)?.roundToInt() ?: "--"}°–${d?.optJSONArray("temperature_2m_max")?.optDouble(0)?.roundToInt() ?: "--"}°C • Rain chance ${d?.optJSONArray("precipitation_probability_max")?.optInt(0) ?: "--"}%"
                else "Weather unavailable. Tap refresh to retry."
            } catch (_: Exception) { weather = "Weather unavailable. Check internet and refresh." }
        }
    }

    suspend fun refreshFeeds() {
        loadingNews = true
        val previousTitles = (headlines + marketHeadlines).map { it.title }.toSet()
        withContext(Dispatchers.IO) {
            val feeds = listOf(
                "https://feeds.bbci.co.uk/news/india/rss.xml" to "India",
                "https://feeds.bbci.co.uk/news/world/asia/india/rss.xml" to "India & Asia",
                "https://feeds.bbci.co.uk/news/world/rss.xml" to "World",
                "https://feeds.bbci.co.uk/news/business/rss.xml" to "Global Business",
                "https://www.cnbc.com/id/10001147/device/rss/rss.html" to "CNBC Markets",
                "https://feeds.finance.yahoo.com/rss/2.0/headline?s=%5EGSPC,%5EIXIC,%5EDJI,BTC-USD&region=US&lang=en-US" to "Global Markets",
                "https://www.moneycontrol.com/rss/marketreports.xml" to "India Markets"
            )
            val all = mutableListOf<Headline>()
            val client = OkHttpClient.Builder().callTimeout(java.time.Duration.ofSeconds(12)).build()
            feeds.forEach { (url, label) ->
                runCatching {
                    client.newCall(Request.Builder().url(url).header("User-Agent", "RunBriefing/1.1 Android").build()).execute().use { response ->
                        val body = response.body?.string().orEmpty()
                        Regex("<item>(.*?)</item>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)).findAll(body).take(8).forEach { m ->
                            val block = m.groupValues[1]
                            fun tag(name: String): String = Regex("<$name(?:\\s+[^>]*)?>(?:<!\\[CDATA\\[(.*?)]]>|(.*?))</$name>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)).find(block)?.let { it.groups[1]?.value ?: it.groups[2]?.value ?: "" }.orEmpty().trim()
                            val title = tag("title").replace("&amp;", "&").replace("&quot;", "\"").replace("&#039;", "'").replace("&apos;", "'")
                            val link = tag("link")
                            if (response.isSuccessful && title.isNotBlank()) all.add(Headline(title, label, link))
                        }
                    }
                }
            }
            val unique = all.distinctBy { it.title }
            headlines = unique.filter { it.source in listOf("India", "India & Asia", "World", "Global Business") }.take(30)
            marketHeadlines = unique.filter { it.source.contains("Market") || it.source.contains("CNBC") || it.source.contains("Business") }.take(40)
            newsStatus = if (headlines.isEmpty()) "Some news feeds are unavailable. Tap refresh to retry." else "Internet RSS feeds checked"
            val newCount = unique.count { it.title !in previousTitles }
            refreshMessage = if (unique.isEmpty()) "No feed results. Check your connection and try again." else if (newCount > 0) "$newCount new headline(s) found" else "Feeds checked — no new headlines this time"
            lastUpdated = SimpleDateFormat("HH:mm, d MMM", Locale.getDefault()).format(Date())
        }
        loadingNews = false
    }

    val scope = rememberCoroutineScope()
    fun refreshAll() { scope.launch { refreshWeather(); refreshFeeds() } }
    LaunchedEffect(Unit) {
        refreshAll()
        // Gentle in-app reminder while the app is open. A true background notification service can be added later.
        delay(120_000)
        while (true) {
            currentQuote = quoteLibrary[quoteIndex % quoteLibrary.size]
            quoteIndex++
            showQuote = true
            delay(20 * 60 * 1000L)
        }
    }

    fun onLocation(loc: Location) {
        val prev = lastLocation
        if (running && !paused && prev != null) {
            val d = prev.distanceTo(loc)
            if (d in 2f..80f) {
                km += d / 1000.0
                route = route + (loc.latitude to loc.longitude)
            }
        } else if (route.isEmpty()) route = listOf(loc.latitude to loc.longitude)
        lastLocation = loc
    }
    fun resetRun() {
        km = 0.0; elapsed = 0L; pausedAccumulated = 0L; pauseStarted = 0L
        lastLocation = null; route = emptyList(); paceSec = 0.0; speed = 0.0
    }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("RunBriefing", fontWeight = FontWeight.Bold) }, actions = { Text(SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date()), modifier = Modifier.padding(end = 14.dp)) }) },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Default.ShowChart, null) }, label = { Text("Markets") })
                    NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Default.School, null) }, label = { Text("SSC") })
                    NavigationBarItem(tab == 3, { tab = 3 }, { Icon(Icons.Default.DirectionsRun, null) }, label = { Text("Run") })
                    NavigationBarItem(tab == 4, { tab = 4 }, { Icon(Icons.Default.Dashboard, null) }, label = { Text("More") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> HomeScreen(Modifier.padding(padding), weather, headlines, newsStatus, loadingNews, lastUpdated, refreshMessage,
                    refresh = { refreshAll() }, openQuote = { currentQuote = quoteLibrary[quoteIndex % quoteLibrary.size]; quoteIndex++; showQuote = true }, goRun = { tab = 3 })
                1 -> MarketsScreen(Modifier.padding(padding), marketHeadlines, loadingNews, lastUpdated, refreshMessage, refresh = { refreshAll() })
                2 -> SscScreen(Modifier.padding(padding))
                3 -> RunScreen(Modifier.padding(padding), running, paused, elapsed, km, paceSec, speed, route,
                    start = {
                        resetRun(); startTime = System.currentTimeMillis(); running = true; paused = false
                        startGps { onLocation(it) }
                    },
                    pause = {
                        if (!paused) { paused = true; pauseStarted = System.currentTimeMillis(); stopGps() }
                        else { pausedAccumulated += System.currentTimeMillis() - pauseStarted; paused = false; startGps { onLocation(it) } }
                    },
                    finish = {
                        running = false; paused = false; stopGps()
                        if (km > 0.01) {
                            val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
                            runs.add(0, RunRecord(date, km, elapsed, if (km > 0) elapsed / km else 0.0, (km * 60).roundToInt()))
                            persistRuns()
                        }
                    })
                else -> MoreScreen(Modifier.padding(padding), runs, openQuote = { currentQuote = quoteLibrary[quoteIndex % quoteLibrary.size]; quoteIndex++; showQuote = true })
            }
            if (showQuote) AlertDialog(
                onDismissRequest = { showQuote = false },
                title = { Text("A moment to reset ✨") },
                text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(currentQuote.quote, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text("— ${currentQuote.author} • ${currentQuote.topic}", style = MaterialTheme.typography.labelMedium)
                    Text(currentQuote.context, style = MaterialTheme.typography.bodyMedium)
                } },
                confirmButton = { TextButton(onClick = { showQuote = false }) { Text("Got it") } },
                dismissButton = { TextButton(onClick = { currentQuote = quoteLibrary[quoteIndex % quoteLibrary.size]; quoteIndex++ }) { Text("Another quote") } }
            )
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier, weather: String, headlines: List<Headline>, status: String, loading: Boolean,
               lastUpdated: String, refreshMessage: String, refresh: () -> Unit, openQuote: () -> Unit, goRun: () -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Good day 👋", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item { Text(SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = refresh, enabled = !loading, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Refresh, null); Text(if (loading) " Updating…" else " Refresh information") }
            OutlinedButton(onClick = openQuote) { Icon(Icons.Default.FormatQuote, null); Text(" Quote") }
        } }
        item { Card { Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text("🌦️ LOCAL WEATHER • GUWAHATI", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp)); Text(weather)
        } } }
        item { Card { Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text("🏃 READY TO RUN?", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Track GPS distance, pace, time and route.")
            Spacer(Modifier.height(8.dp)); Button(onClick = goRun) { Text("Start a run") }
        } } }
        item { Text("📰 TOP HEADLINES", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { Text("$status • Updated $lastUpdated", style = MaterialTheme.typography.bodySmall) }
        item { Text(refreshMessage, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium) }
        if (headlines.isEmpty()) item { Text("No headlines loaded yet. Check your internet connection and tap Refresh.") }
        items(headlines.take(10)) { h -> Card { Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text(h.title, fontWeight = FontWeight.SemiBold)
            Text(h.source, style = MaterialTheme.typography.labelSmall)
        } } }
        item { Text("Explore Markets for global business and trading headlines, or SSC for syllabus topics and timed study sessions.", style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
fun MarketsScreen(modifier: Modifier, headlines: List<Headline>, loading: Boolean, lastUpdated: String, refreshMessage: String, refresh: () -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Global Trader Desk", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item { Text("Global market headlines • India business • macroeconomics • risk awareness") }
        item { Card { Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text("TRADER BRIEFING", fontWeight = FontWeight.Bold)
            Text("Refresh pulls the latest items available from public RSS feeds. This section is news, not live exchange quotes or a buy/sell signal.")
            Spacer(Modifier.height(8.dp))
            Button(onClick = refresh, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Refresh, null); Text(if (loading) "  Refreshing feeds…" else "  Refresh global market news")
            }
            Text("Last refresh: $lastUpdated", style = MaterialTheme.typography.labelSmall)
            Text(refreshMessage, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
        } } }
        item { Text("GLOBAL & INDIAN MARKET NEWS", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        if (headlines.isEmpty()) item { Text("Market feeds are empty or unavailable. Check internet and refresh.") }
        items(headlines) { h -> Card { Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text(h.title, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp)); Text(h.source, style = MaterialTheme.typography.labelSmall)
            if (h.link.startsWith("http")) {
                val context = LocalContext.current
                TextButton(onClick = { runCatching { context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(h.link))) } }) { Text("Open article") }
            }
        } } }
        item { Text("For decisions, verify the source, publication time, filings, price data and risk. RSS availability depends on each publisher and internet access.", style = MaterialTheme.typography.bodySmall) }
    }
}

private data class StudyTopic(val subject: String, val topic: String, val minutes: Int)
private val sscTopics = listOf(
    StudyTopic("Quantitative Aptitude", "Number System & Simplification", 25),
    StudyTopic("Quantitative Aptitude", "Percentage", 25),
    StudyTopic("Quantitative Aptitude", "Ratio and Proportion", 25),
    StudyTopic("Quantitative Aptitude", "Profit, Loss and Discount", 30),
    StudyTopic("Quantitative Aptitude", "Time and Work", 30),
    StudyTopic("Quantitative Aptitude", "Time, Speed and Distance", 30),
    StudyTopic("Reasoning", "Analogy and Classification", 25),
    StudyTopic("Reasoning", "Series", 25),
    StudyTopic("Reasoning", "Coding-Decoding", 25),
    StudyTopic("Reasoning", "Syllogism and Venn Diagrams", 30),
    StudyTopic("English", "Grammar: Parts of Speech", 25),
    StudyTopic("English", "Error Spotting", 25),
    StudyTopic("English", "Vocabulary and One-word Substitution", 25),
    StudyTopic("General Awareness", "Indian Polity: Constitution Basics", 30),
    StudyTopic("General Awareness", "Modern Indian History", 30),
    StudyTopic("General Awareness", "Indian Geography", 30),
    StudyTopic("General Awareness", "General Science: Biology Basics", 25),
    StudyTopic("Computer", "Computer Fundamentals", 20)
)

@Composable
fun SscScreen(modifier: Modifier) {
    var selectedSubject by remember { mutableStateOf("Quantitative Aptitude") }
    var selectedTopic by remember { mutableStateOf<StudyTopic?>(null) }
    var remaining by remember { mutableIntStateOf(0) }
    var timerRunning by remember { mutableStateOf(false) }
    var completed by remember { mutableStateOf(false) }
    LaunchedEffect(timerRunning, remaining) {
        if (timerRunning && remaining > 0) {
            delay(1000)
            remaining -= 1
            if (remaining <= 0) { remaining = 0; timerRunning = false; completed = true }
        }
    }
    val subjects = sscTopics.map { it.subject }.distinct()
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("SSC Study Planner", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item { Text("Starter syllabus map for SSC-style preparation. Match topics to your target exam’s latest official notification.") }
        item { Text("SUBJECTS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        item { Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            subjects.forEach { subject ->
                FilterChip(selected = selectedSubject == subject, onClick = { selectedSubject = subject; selectedTopic = null; completed = false }, label = { Text(subject) })
            }
        } }
        item { Text("TOPICS • $selectedSubject", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        items(sscTopics.filter { it.subject == selectedSubject }) { topic ->
            Card(onClick = { if (!timerRunning) { selectedTopic = topic; remaining = topic.minutes * 60; completed = false } }) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(topic.topic, fontWeight = FontWeight.SemiBold); Text("Suggested focus: ${topic.minutes} minutes", style = MaterialTheme.typography.bodySmall) }
                    if (selectedTopic == topic) Icon(Icons.Default.CheckCircle, null)
                    else Icon(Icons.Default.ChevronRight, null)
                }
            }
        }
        item { Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("FOCUS TIMER", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(selectedTopic?.topic ?: "Select a topic above")
            Text(fmt(remaining.toLong()), style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold)
            if (completed) Text("Time is up. Session stopped automatically — take a short break or select the next topic.", color = MaterialTheme.colorScheme.primary)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { if (selectedTopic != null && remaining == 0) remaining = selectedTopic!!.minutes * 60; if (selectedTopic != null && remaining > 0) { timerRunning = true; completed = false } }, enabled = selectedTopic != null && !timerRunning) { Icon(Icons.Default.PlayArrow, null); Text(" Start") }
                OutlinedButton(onClick = { timerRunning = false; remaining = selectedTopic?.minutes?.times(60) ?: 0; completed = false }, enabled = selectedTopic != null) { Text("Reset") }
                OutlinedButton(onClick = { timerRunning = false }, enabled = timerRunning) { Text("Stop") }
            }
        } } }
        item { Text("Timer counts down on screen and stops itself at zero. Keep the app open during a study session in this prototype.", style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
fun MoreScreen(modifier: Modifier, runs: List<RunRecord>, openQuote: () -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Your Toolkit", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item { Card { Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text("✨ DAILY QUOTE REMINDER", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Motivation, philosophy, logic, trading, studying, optimism and running — with attribution and context.")
            Spacer(Modifier.height(8.dp)); Button(onClick = openQuote) { Icon(Icons.Default.FormatQuote, null); Text("  Show a quote") }
        } } }
        item { Text("RUNNING COACH", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { CoachCard("Goal • 3.2 km in 11:00", "Target pace about 3:26/km, or 400 m in about 1:22.5. Build gradually and take recovery days.") }
        item { CoachCard("Intervals", "Warm up 12–15 minutes, then 6 × 400 m at controlled effort with 2 minutes easy recovery. Cool down.") }
        item { CoachCard("Easy run", "25–40 minutes conversational pace, adjusted to your current weekly volume.") }
        item { Text("RUN STATS", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { Card { Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text("Saved runs: ${runs.size}")
            Text("Total distance: %.2f km".format(Locale.US, runs.sumOf { it.km }))
            Text("Longest run: ${runs.maxByOrNull { it.km }?.let { "%.2f km".format(Locale.US, it.km) } ?: "—"}")
        } } }
        items(runs.take(10)) { r -> Card { Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Text("${r.date} • %.2f km".format(Locale.US, r.km), fontWeight = FontWeight.SemiBold)
            Text("${fmt(r.seconds)} • ${formatPace(r.paceSecPerKm)}/km")
        } } }
    }
}

@Composable
fun RunScreen(modifier: Modifier, running: Boolean, paused: Boolean, elapsed: Long, km: Double, paceSec: Double, speed: Double,
              route: List<Pair<Double, Double>>, start: () -> Unit, pause: () -> Unit, finish: () -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("GPS Run", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item { Card { Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("%.2f".format(Locale.US, km), style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Bold)
            Text("KILOMETRES")
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Metric("TIME", fmt(elapsed)); Metric("AVG PACE", if (paceSec > 0) "${(paceSec/60).toInt()}:${(paceSec%60).toInt().toString().padStart(2,'0')}/km" else "--:--")
                Metric("SPEED", "%.1f km/h".format(Locale.US, speed))
            }
            Spacer(Modifier.height(12.dp))
            Text("Estimated calories: ${(km * 60).roundToInt()} kcal", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(14.dp))
            if (!running) Button(onClick = start, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.PlayArrow, null); Text("  Start run") }
            else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = pause, modifier = Modifier.weight(1f)) { Icon(if (paused) Icons.Default.PlayArrow else Icons.Default.Pause, null); Text(if (paused) " Resume" else " Pause") }
                    Button(onClick = finish, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Stop, null); Text(" Finish") }
                }
            }
        } } }
        item { Text("ROUTE MAP PREVIEW", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        item { Card { Column(Modifier.fillMaxWidth().padding(10.dp)) {
            if (route.size >= 2) RouteSketch(route, Modifier.fillMaxWidth().height(190.dp))
            else Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) { Text("Your route will appear here after GPS points are recorded.") }
            Text("This is a simplified route sketch, not a street map. A map provider/API key is required for a real map.", style = MaterialTheme.typography.bodySmall)
        } } }
        item { Text("For best accuracy, allow location access and test outdoors. This starter is not yet a full background tracking service; keep the app open during runs.", style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
fun RouteSketch(points: List<Pair<Double, Double>>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val minX = points.minOf { it.first }; val maxX = points.maxOf { it.first }
        val minY = points.minOf { it.second }; val maxY = points.maxOf { it.second }
        val dx = (maxX - minX).coerceAtLeast(0.00001); val dy = (maxY - minY).coerceAtLeast(0.00001)
        val path = Path()
        points.forEachIndexed { i, p ->
            val x = ((p.first - minX) / dx * (size.width - 24) + 12).toFloat()
            val y = (size.height - ((p.second - minY) / dy * (size.height - 24) + 12)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, color = androidx.compose.ui.graphics.Color(0xFF1565C0), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 5f))
        drawCircle(androidx.compose.ui.graphics.Color(0xFF2E7D32), 7f, Offset(
            ((points.first().first - minX) / dx * (size.width - 24) + 12).toFloat(),
            (size.height - ((points.first().second - minY) / dy * (size.height - 24) + 12)).toFloat()
        ))
    }
}

@Composable
fun CoachScreen(modifier: Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Personal running coach", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { Text("Goal: 3.2 km in 11:00 • target pace 3:26/km • 400 m split about 1:22.5") }
        item { CoachCard("Day 1 • Intervals", "Warm up 12–15 min, then 6 × 400 m at controlled fast effort with 2 min easy recovery. Cool down 10 min.") }
        item { CoachCard("Day 2 • Easy run", "25–40 minutes conversational pace, then 4 relaxed 15-second strides.") }
        item { CoachCard("Day 3 • Threshold", "3 × 6 minutes comfortably hard with 2 minutes easy recovery.") }
        item { CoachCard("Day 4 • Recovery", "Rest or 20–30 minutes very easy plus mobility.") }
        item { CoachCard("Day 5 • Pace practice", "4–6 × 600 m at controlled effort with 2–3 minutes recovery. Do not force goal pace if form breaks down.") }
        item { CoachCard("Day 6 • Easy endurance", "35–50 minutes easy, adjusted to current weekly volume.") }
        item { CoachCard("Day 7 • Rest", "Full rest or gentle walking. Stop for chest pain, dizziness or sharp pain.") }
        item { Text("This is a general template. Adjust to your current fitness and recovery; goal pace is demanding.", style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
fun CoachCard(title: String, body: String) {
    Card { Column(Modifier.fillMaxWidth().padding(16.dp)) { Text(title, fontWeight = FontWeight.Bold); Spacer(Modifier.height(6.dp)); Text(body) } }
}

@Composable
fun StatsScreen(modifier: Modifier, runs: List<RunRecord>) {
    val totalKm = runs.sumOf { it.km }
    val best = runs.maxByOrNull { it.km }
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Performance analytics", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { Card { Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text("Saved runs: ${runs.size}"); Text("Total distance: %.2f km".format(Locale.US, totalKm))
            Text("Longest run: ${best?.let { "%.2f km".format(Locale.US, it.km) } ?: "—"}")
            Text("Goal distance: 3.2 km • goal time: 11:00")
        } } }
        if (runs.isEmpty()) item { Text("Finish a run to build your history and analytics.") }
        items(runs) { r -> Card { Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text("${r.date} • %.2f km".format(Locale.US, r.km), fontWeight = FontWeight.Bold)
            Text("Time ${fmt(r.seconds)} • Pace ${formatPace(r.paceSecPerKm)}/km • ~${r.calories} kcal")
        } } }
    }
}

@Composable
fun Metric(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(label, style = MaterialTheme.typography.labelMedium); Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
}

fun fmt(s: Long): String {
    val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h,m,sec) else "%02d:%02d".format(m,sec)
}
fun formatPace(sec: Double): String = if (sec > 0 && sec.isFinite()) "%d:%02d".format((sec/60).toInt(), (sec%60).toInt()) else "--:--"
