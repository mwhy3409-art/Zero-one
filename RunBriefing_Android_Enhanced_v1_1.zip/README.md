# RunBriefing Android — v1.1 enhanced prototype

RunBriefing brings daily information, market headlines, SSC study sessions and running tools into one Android app.

## New in v1.1
- Refresh controls on Home and Markets to fetch fresh internet content.
- Global Trader Desk with RSS headlines from BBC Business, CNBC, Yahoo Finance and Moneycontrol where feeds are available. Article links open in the browser.
- SSC Study Planner with subject categories and starter topic lists for Quantitative Aptitude, Reasoning, English, General Awareness and Computer Fundamentals.
- Topic-specific focus timer. Selecting a topic loads its suggested duration; the countdown stops automatically at zero.
- Quote dialog with quote, attribution, category and short context. A gentle in-app reminder appears while the app remains open, and users can request another quote manually.
- Existing Guwahati weather, general news, GPS run tracking, run history and 3.2 km / 11-minute running goal retained.

## Build the APK from an Android phone (cloud build)
This project is source code; it is **not a compiled APK**.

1. Download and extract this ZIP on your phone.
2. Upload the project files to a GitHub repository (the `.github/workflows/build-apk.yml` file must be included).
3. Open the repository's **Actions** tab and run **Build Android APK**.
4. When the workflow succeeds, download the `RunBriefing-debug-apk` artifact, extract it and install `app-debug.apk`. Android may ask you to permit installation from your browser or file manager.
5. If the build fails, open the workflow log and use the first red error to troubleshoot; this project has not been compiled or device-tested in this environment.

## How to edit the project
Edit `app/src/main/java/com/example/runbriefing/MainActivity.kt`:
- **News feeds:** edit the `feeds` list inside `refreshFeeds()`.
- **Quotes:** edit `quoteLibrary`. Each quote includes text, attribution, category and context.
- **SSC syllabus and focus durations:** edit `sscTopics`. Each `StudyTopic` has a subject, topic and suggested minutes.
- **Running goal:** update the goal text in `MoreScreen()` and `CoachScreen()`.
- **Weather location:** update the latitude/longitude in the Open-Meteo URL in `refreshWeather()`.

After editing, rebuild the APK with GitHub Actions and install the new artifact. These settings are currently source-code editable, not editable through an admin dashboard inside the app.

## Important limitations
- Market section refreshes public RSS headlines. It does **not** provide exchange-grade real-time NSE/BSE prices, depth, signals, or guaranteed real-time delivery. RSS availability and update times depend on publishers. Do not use headlines alone to trade.
- Guwahati weather comes from Open-Meteo. This prototype does not include official severe-weather alerts.
- Quotes appear in-app while the app is open; reliable scheduled background notifications have not been implemented.
- The SSC syllabus is a starter outline, not a guarantee of complete or current coverage. Check the latest official notification for the specific exam.
- The focus timer is intended to remain open on screen; it is not yet a background timer/notification service.
- GPS route display is a simplified sketch, not a street map. Keep the app open during runs; production-grade background tracking has not been implemented.
- Run history is stored locally on the device. There is no account sync or cloud database yet.
- The debug APK is for testing and is not a Play Store-signed release.
